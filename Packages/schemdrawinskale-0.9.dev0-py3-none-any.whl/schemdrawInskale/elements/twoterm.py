''' Two-terminal element definitions '''
from __future__ import annotations
from typing import Optional
import math
from typing import Sequence

from .elements import Element, Element2Term, gap
from ..util import Point, linspace
from ..segments import Segment, SegmentArc, SegmentText, SegmentCircle, SegmentPoly

resheight = 0.25      # Resistor height
reswidth = 1.0 / 6   # Full (inner) length of resistor is 1.0 data unit


class ResistorIEEE(Element2Term):
    ''' Resistor (IEEE/U.S. style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(
            [(0, 0), (0.5*reswidth, resheight), (1.5*reswidth, -resheight),
             (2.5*reswidth, resheight), (3.5*reswidth, -resheight),
             (4.5*reswidth, resheight), (5.5*reswidth, -resheight), (6*reswidth, 0)], userparams=self._userparams))


class ResistorIEC(Element2Term):
    ''' Resistor as box (IEC/European style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(
            [(0, 0), (0, resheight), (reswidth*6, resheight),
             (reswidth*6, -resheight), (0, -resheight), (0, 0),
             gap, (reswidth*6, 0)], userparams=self._userparams))


class ResistorVarIEEE(ResistorIEEE):
    ''' Variable resistor (U.S. style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(1.5*reswidth, -resheight*2), (4.5*reswidth, reswidth*3.5)],
                                     arrow='->', arrowwidth=.16, arrowlength=.2, userparams=self._userparams))


class ResistorVarIEC(ResistorIEC):
    ''' Variable resistor (European style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(1*reswidth, -resheight*2), (5*reswidth, reswidth*3.5)],
                                     arrow='->', arrowwidth=.16, arrowlength=.2, userparams=self._userparams))


class Thermistor(ResistorIEC):
    ''' Thermistor '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, -resheight-.2), (.2, -resheight-.2), (1, resheight+.2)], userparams=self._userparams))


class PhotoresistorIEEE(ResistorIEEE):
    ''' Photo-resistor (U.S. style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(.7, .75), (.4, .4)], arrow='->',
                                     arrowwidth=.16, arrowlength=.2, userparams=self._userparams))
        self.segments.append(Segment([(1, .75), (.7, .4)], arrow='->',
                                     arrowwidth=.16, arrowlength=.2, userparams=self._userparams))


class PhotoresistorIEC(ResistorIEC):
    ''' Photo-resistor (European style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(.7, .75), (.4, .4)], arrow='->',
                                     arrowwidth=.16, arrowlength=.2, userparams=self._userparams))
        self.segments.append(Segment([(1, .75), (.7, .4)], arrow='->',
                                     arrowwidth=.16, arrowlength=.2, userparams=self._userparams))


class Rshunt(ResistorIEC):
    ''' Shunt Resistor '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0),
                                      (-resheight*1.5, -resheight),
                                      (-resheight*1.5, -resheight*2)], userparams=self._userparams))
        self.segments.append(Segment([(reswidth*6, 0),
                                      (reswidth*6+resheight*1.5, -resheight),
                                      (reswidth*6+resheight*1.5, -resheight*2)], userparams=self._userparams))
        self.anchors['v1'] = (-resheight*1.5, -resheight*2)
        self.anchors['v2'] = (reswidth*6+resheight*1.5, -resheight*2)


class Capacitor(Element2Term):
    ''' Capacitor (flat plates)

        Args:
            polar: Add polarity + sign
    '''
    _element_defaults = {
        'polar': False
    }
    def __init__(self, *, polar: Optional[bool] = None, **kwargs):
        super().__init__(**kwargs)
        capgap = 0.18
        self.segments.append(Segment([(0, 0), gap, (0, resheight), (0, -resheight), gap,
                                     (capgap, resheight), (capgap, -resheight), gap,
                                     (capgap, 0)], userparams=self._userparams))
        if self.params['polar']:
            self.segments.append(SegmentText((-capgap*1.2, capgap), '+', userparams=self._userparams))


class Capacitor2(Element2Term):
    ''' Capacitor (curved bottom plate)

        Args:
            polar: Add polarity + sign
    '''
    _element_defaults = {
        'polar': False
    }
    def __init__(self, *, polar: Optional[bool] = None, **kwargs):
        super().__init__(**kwargs)
        capgap = 0.18
        self.segments.append(Segment([(0, 0), gap, (0, resheight),
                                     (0, -resheight), gap, (capgap, 0)], userparams=self._userparams))
        self.segments.append(SegmentArc((capgap*1.5, 0), width=capgap*1.5,
                                        height=resheight*2.5, theta1=105, theta2=-105))

        if self.params['polar']:
            self.segments.append(SegmentText((-capgap*1.2, capgap), '+', userparams=self._userparams))


class CapacitorVar(Capacitor):
    ''' Variable capacitor '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(-2*reswidth, -resheight), (3*reswidth, reswidth*2)],
                                     arrow='->', arrowwidth=.2, arrowlength=.2, userparams=self._userparams))


class CapacitorTrim(Capacitor):
    ''' Trim capacitor '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        capgap = 0.18
        # Line endpoints
        p1 = Point((-1.8*reswidth, -resheight))
        p2 = Point((1.8*reswidth+capgap, resheight))
        dx = p2.x - p1.x
        dy = p2.y - p1.y

        self.segments.append(Segment([p1, p2], userparams=self._userparams))

        tlen = .14
        theta = math.atan2(dy, dx) + math.radians(90)
        t1 = Point((p2.x + tlen * math.cos(theta),
                    p2.y + tlen * math.sin(theta)))
        t2 = Point((p2.x + tlen * math.cos(theta-math.pi),
                    p2.y + tlen * math.sin(theta-math.pi)))
        self.segments.append(Segment([t1, t2]))


class Crystal(Element2Term):
    ''' Crystal oscillator '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        xgap = 0.2
        self.segments.append(Segment(
            [(0, 0), gap, (0, resheight), (0, -resheight), gap,
             (xgap/2, resheight), (xgap/2, -resheight), (xgap*1.5, -resheight),
             (xgap*1.5, resheight), (xgap/2, resheight), gap,
             (xgap*2, resheight), (xgap*2, -resheight), gap, (xgap*2, 0)], userparams=self._userparams))


class Diode(Element2Term):
    ''' Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0), gap, (resheight*1.4, resheight),
                                      (resheight*1.4, -resheight), gap, (resheight*1.4, 0)], userparams=self._userparams))
        self.segments.append(SegmentPoly([(0, resheight), (resheight*1.4, 0), (0, -resheight)]))


class Schottky(Diode):
    ''' Schottky Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        schottky_width = 0.1
        self.segments.append(Segment(
            [(resheight*1.4, resheight),
             (resheight*1.4-schottky_width, resheight),
             (resheight*1.4-schottky_width, resheight-schottky_width)], userparams=self._userparams))
        self.segments.append(Segment(
            [(resheight*1.4, -resheight),
             (resheight*1.4+schottky_width, -resheight),
             (resheight*1.4+schottky_width, -resheight+schottky_width)], userparams=self._userparams))


class DiodeTunnel(Diode):
    ''' Tunnel Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        tunnel_width = 0.1
        self.segments.append(Segment([(resheight*1.4, resheight),
                                      (resheight*1.4-tunnel_width, resheight)], userparams=self._userparams))
        self.segments.append(Segment([(resheight*1.4, -resheight),
                                      (resheight*1.4-tunnel_width, -resheight)], userparams=self._userparams))


class DiodeShockley(Element2Term):
    ''' Shockley Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0), (resheight*1.4, 0), (resheight*1.4, resheight),
                                      (resheight*1.4, -resheight), gap, (resheight*1.4, 0)], userparams=self._userparams))
        self.segments.append(Segment([(0, -resheight), (0, resheight), (resheight*1.4, 0)], userparams=self._userparams))


class Zener(Diode):
    ''' Zener Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        zener_width = 0.1
        self.segments.append(Segment([(resheight*1.4, resheight),
                                      (resheight*1.4+zener_width, resheight+zener_width)], userparams=self._userparams))
        self.segments.append(Segment([(resheight*1.4, -resheight),
                                      (resheight*1.4-zener_width, -resheight-zener_width)], userparams=self._userparams))


class Varactor(Element2Term):
    ''' Varactor Diode/Varicap/Variable Capacitance Diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        capgap = .13
        self.segments.append(Segment([(0, 0), gap,
                                     (resheight*1.4, resheight), (resheight*1.4, -resheight),
                                     gap,
                                     (resheight*1.4+capgap, resheight), (resheight*1.4+capgap, -resheight),
                                     gap,
                                     (resheight*1.4+capgap, 0)], userparams=self._userparams))
        self.segments.append(SegmentPoly([(0, resheight), (resheight*1.4, 0), (0, -resheight)]))


class LED(Diode):
    ''' Light emitting diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(resheight, resheight*1.5), (resheight*2, resheight*3.25)],
                                     arrow='->', arrowwidth=.16, arrowlength=.2, userparams=self._userparams))
        self.segments.append(Segment([(resheight*.1, resheight*1.5), (resheight*1.1, resheight*3.25)],
                                     arrow='->', arrowwidth=.16, arrowlength=.2, userparams=self._userparams))
        self.params['lblloc'] = 'bot'


class LED2(Diode):
    ''' Light emitting diode (curvy light lines) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        x = linspace(-1, 1)
        y = [-x0*(x0-.7)*(x0+.7)/2 + resheight*2.5 for x0 in x]
        x = linspace(resheight*.75, resheight*1.25)

        theta = 20
        p = [Point((x0, y0)).rotate(theta) for x0, y0 in zip(x, y)]
        p2 = [Point((x0-.2, y0)).rotate(theta) for x0, y0 in zip(x, y)]

        pa = Point((x[0], y[0]+.1)).rotate(theta)
        pa2 = Point((x[0]-.2, y[0]+.1)).rotate(theta)

        self.segments.append(Segment(p, userparams=self._userparams))
        self.segments.append(Segment(p2, userparams=self._userparams))
        self.segments.append(Segment((p[1], pa), arrow='->', arrowwidth=.15, arrowlength=.2, userparams=self._userparams))
        self.segments.append(Segment((p2[1], pa2), arrow='->', arrowwidth=.15, arrowlength=.2, userparams=self._userparams))
        self.params['lblloc'] = 'bot'


class Photodiode(Diode):
    ''' Photo-sensitive diode '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        x = linspace(-1, 1)
        y = [-x0*(x0-.7)*(x0+.7)/2 + resheight*2.5 for x0 in x]
        x = linspace(resheight*.75, resheight*1.25)
        theta = 20
        p = [Point((x0, y0)).rotate(theta) for x0, y0 in zip(x, y)]
        p2 = [Point((x0-.2, y0)).rotate(theta) for x0, y0 in zip(x, y)]

        pa = Point((x[-1], y[-1]-.1)).rotate(theta)
        pa2 = Point((x[-1]-.2, y[-1]-.1)).rotate(theta)
        self.segments.append(Segment(p, userparams=self._userparams))
        self.segments.append(Segment(p2, userparams=self._userparams))
        self.segments.append(Segment((p[-2], pa), arrow='->', arrowwidth=.15, arrowlength=.2, userparams=self._userparams))
        self.segments.append(Segment((p2[-2], pa2), arrow='->', arrowwidth=.15, arrowlength=.2, userparams=self._userparams))
        self.params['lblloc'] = 'bot'


class PotentiometerIEEE(ResistorIEEE):
    ''' Potentiometer (U.S. style)

        Anchors:
            tap
    '''
    # Ok, this has three terminals, but is works like a two-term with lead extension
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        potheight = .72
        self.anchors['tap'] = (reswidth*3, potheight)
        self.params['lblloc'] = 'bot'
        self.segments.append(Segment([(reswidth*3, potheight), (reswidth*3, reswidth*1.5)],
                                     arrow='->', arrowwidth=.15, arrowlength=.25, userparams=self._userparams))


class PotentiometerIEC(ResistorIEC):
    ''' Potentiometer (European style)

        Anchors:
            tap
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        potheight = .72
        self.anchors['tap'] = (reswidth*3, potheight)
        self.elmparams['lblloc'] = 'bot'
        self.segments.append(Segment([(reswidth*3, potheight), (reswidth*3, reswidth*2)],
                                     arrow='->', arrowwidth=.15, arrowlength=.22, userparams=self._userparams))


class Diac(Element2Term):
    ''' Diac (diode for alternating current) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(
            [(0, 0), gap, (resheight*1.4, resheight*1.8),
             (resheight*1.4, -resheight*1.8), gap,
             (0, resheight*1.8), (0, -resheight*1.8), gap, (resheight*1.4, 0)], userparams=self._userparams))
        self.segments.append(SegmentPoly([(0, -resheight-.25), (resheight*1.4, -.25),
                                          (0, -resheight+.25)]))
        self.segments.append(SegmentPoly([(resheight*1.4, resheight+.25), (0, .25),
                                          (resheight*1.4, resheight-.25)]))


class Triac(Diac):
    ''' Triac

        Anchors:
            gate
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(resheight*1.4, .25), (resheight*1.4+.5, .5)], userparams=self._userparams))
        self.anchors['gate'] = (resheight*1.4+.5, .5)


class SCR(Diode):
    ''' Silicon controlled rectifier (or thyristor)

        Anchors:
            gate
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(
            [(resheight*1.4, 0), (resheight*1.4+.3, -.3), (resheight*1.4+.3, -.5)], userparams=self._userparams))
        self.anchors['gate'] = (resheight*1.4+.3, -.5)


class Memristor(Element2Term):
    ''' Memristor (resistor with memory) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        mr = 0.2
        self.segments.append(Segment(
            [(0, 0), (mr, 0), (mr, -mr*.75), (mr*2, -mr*.75), (mr*2, mr*.75),
             (mr*3, mr*.75), (mr*3, -mr*.75), (mr*4, -mr*.75), (mr*4, 0),
             (mr*5, 0)], userparams=self._userparams))
        self.segments.append(Segment(
            [(0, mr*1.25), (mr*5, mr*1.25), (mr*5, mr*-1.25), (0, mr*-1.25),
             (0, mr*1.25)], userparams=self._userparams))
        self.segments.append(SegmentPoly(
            [(0, mr*1.25), (0, -mr*1.25), (mr/2, -mr*1.25), (mr/2, mr*1.25)],
            fill='black'))


class Memristor2(Element2Term):
    ''' Memristor (resistor with memory), alternate style '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        mr = 0.2
        mrv = .25
        self.segments.append(Segment(
            [(0, 0), (0, mrv), (mr, mrv), (mr, -mrv), (mr*2, -mrv), (mr*2, mrv),
             (mr*3, mrv), (mr*3, -mrv), (mr*4, -mrv), (mr*4, mrv),
             (mr*5, mrv), (mr*5, -mrv), (mr*6, -mrv), (mr*6, 0),
             (mr*7, 0)], userparams=self._userparams))


class Josephson(Element2Term):
    ''' Josephson Junction '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(
            [(0, 0), gap, (-resheight, resheight), (resheight, -resheight),
             gap, (resheight, resheight), (-resheight, -resheight),
             gap, (0, 0)], userparams=self._userparams))


class FuseUS(Element2Term):
    ''' Fuse (U.S. Style)

        Args:
            dots: Show dots on connections to fuse
    '''
    _element_defaults = {
        'dots': True
    }
    def __init__(self, *, dots: Optional[bool] = None, **kwargs):
        super().__init__(**kwargs)
        fuser = .12
        fusex = linspace(fuser*2, 1+fuser)
        fusey = [math.sin(x) * resheight for x in linspace(0, 2*math.pi)]
        self.segments.append(Segment(list(zip(fusex, fusey)), userparams=self._userparams))
        self.segments.append(Segment([(0, 0), gap, (1+fuser*3, 0)], userparams=self._userparams))
        if self.params['dots']:
            self.fill(kwargs.get('fill', 'bg'))

    def fill(self, color: bool | str = True) -> 'Element':
        ''' Set element fill '''
        fuser = .12
        self.segments.append(SegmentCircle(
            (fuser, 0), fuser, zorder=4, fill=color))
        self.segments.append(SegmentCircle(
            (fuser*2+1, 0), fuser, zorder=4, fill=color))
        super().fill(color)
        return self


class FuseIEEE(ResistorIEC):
    ''' Fuse (IEEE Style) '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0), (reswidth*6, 0)], userparams=self._userparams))


class FuseIEC(ResistorIEC):
    ''' Fuse (IEC Style) '''    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        dx = resheight*.66
        self.segments.append(Segment([(dx, resheight), (dx, -resheight)], userparams=self._userparams))
        self.segments.append(Segment([(6*reswidth-dx, resheight),
                                      (6*reswidth-dx, -resheight)], userparams=self._userparams))


class Breaker(Element2Term):
    ''' Circuit breaker

        Args:
            dots: Show connection dots
    '''
    _element_defaults = {
        'dots': True
    }
    def __init__(self, *, dots: Optional[bool] = None, **kwargs):
        super().__init__(**kwargs)
        theta1 = 25 if dots else 10
        theta2 = 155 if dots else 170
        self.segments.append(Segment(
            [(0, 0), gap, (1, 0)], userparams=self._userparams))
        self.segments.append(SegmentArc(
            (.5, 0), 1, .65, theta1=theta1, theta2=theta2))
        if self.params['dots']:
            rad = .12
            self.segments.append(SegmentCircle((rad, 0), rad, zorder=4))
            self.segments.append(SegmentCircle((1-rad, 0), rad, zorder=4))


def cycloid(loops: int = 4, ofst: Sequence[float] = (0, 0),
            a: float = .06, b: float = .19, norm: bool = True,
            vertical: bool = False,
            flip: bool = False) -> list[tuple[float, float]]:
    ''' Generate a prolate cycloid (inductor spiral) that
        will always start and end at y=0.

        Args:
            loops: Number of loops
            a, b: Parameters. b>a for prolate (loopy) cycloid
            norm: Normalize the length to 1
            vertical: draw vertically (swap x, y)
            flip: flip orientation (invert y)

        Returns:
            List of (x, y) coordinates defining the cycloid
    '''
    yint = math.acos(a/b)  # y-intercept
    t = linspace(yint, 2*(loops+1)*math.pi-yint, num=loops*50)
    x = [a*t0 - b*math.sin(t0) for t0 in t]
    y = [a - b*math.cos(t0) for t0 in t]
    x = [xx - x[0] for xx in x]  # Shift to start at 0,0

    if norm:
        x = [xx / (x[-1]-x[0]) for xx in x]  # Normalize length to 1

    if flip:
        y = [-yy for yy in y]

    y = [yy * (max(y)-min(y))/(resheight) for yy in y]  # Normalize to resistor width

    if vertical:
        x, y = y, x

    x = [xx + ofst[0] for xx in x]
    y = [yy + ofst[1] for yy in y]

    path = list(zip(x, y))
    return path


class InductorIEC(Element2Term):
    ''' Inductor '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        ind_w = .25
        self.segments.append(Segment([(0, 0), gap, (1, 0)], userparams=self._userparams))
        for i in range(4):
            self.segments.append(SegmentArc(
                [(i*2+1)*ind_w/2, 0], theta1=0, theta2=180,
                width=ind_w, height=ind_w))


class Inductor2(Element2Term):
    ''' Inductor, drawn as cycloid (loopy)

        Args:
            loops: Number of inductor loops [default: 4]
    '''
    _element_defaults = {
        'loops': 4,
    }
    def __init__(self, *, loops: Optional[int] = None, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment(cycloid(loops=self.params['loops']), userparams=self._userparams))


class CPE(Element2Term):
    ''' Constant Phase Element '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        capgap = 0.25
        offset = 0.25
        self.segments.append(Segment([(0, 0), (-offset, 0), gap, (offset, 0),
                                      (0, -resheight), gap, (capgap, 0)], userparams=self._userparams))
        self.segments.append(Segment([(0, 0), (-offset, 0), gap, (offset, 0),
                                      (0, resheight), gap, (capgap, 0)], userparams=self._userparams))
        self.segments.append(Segment([(0, 0), (-offset, resheight), gap,
                                      (0, -resheight), gap, (capgap, 0)], userparams=self._userparams))
        self.segments.append(Segment([(0, 0), (-offset, -resheight), gap,
                                      (0, -resheight), gap, (capgap, 0)], userparams=self._userparams))


class SparkGap(Element2Term):
    ''' Spark Gap '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0), (.3, 0), gap, (.7, 0), (1, 0)], userparams=self._userparams))
        # Arrow coords overlap a bit since default arrow is offset by linewidth
        self.segments.append(Segment([(.3, 0), (.52, 0)], arrow='->', arrowwidth=.2, userparams=self._userparams))
        self.segments.append(Segment([(.7, 0), (.48, 0)], arrow='->', arrowwidth=.2, userparams=self._userparams))


class Nullator(Element2Term):
    ''' Nullator

        This element does not support filling
    '''
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.segments.append(Segment([[0, 0], [0, 0], gap, [1, 0], [1, 0]], userparams=self._userparams))
        self.segments.append(SegmentArc(center=[0.5,0], width=1, height=0.5, theta1=0, theta2=360))
        self.elmparams['theta'] = 90


class Norator(Element2Term):
    ''' Norator '''
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.segments.append(Segment([[0, 0], [0, 0], gap, [1, 0], [1, 0]], userparams=self._userparams))
        self.segments.append(SegmentCircle([0.25, 0], 0.25,))
        self.segments.append(SegmentCircle([1-0.25, 0], 0.25,))
        self.elmparams['theta'] = 90


class CurrentMirror(Element2Term):
    ''' Current mirror with optional common terminal

        Anchors:
            * scommon
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([(0, 0), (0, 0), gap, (1, 0), (1, 0)], userparams=self._userparams))
        # in order to prevent graphical glitches due to overlapping outlines when filling, draw fill before outline
        # fill is drawn here. The outline is disabled to prevent anti-aliasing glitches
        # ideally, the outline would be disabled with ls='None', but this does not work in testing, so lw=1e-9 is here
        # as a fallback. 0 cannot be used because it would be ignored by the style logic
        self.segments.append(SegmentCircle([0.3, 0], 0.3, lw=1e-9, ls="None"))
        self.segments.append(SegmentCircle([1 - 0.3, 0], 0.3, lw=1e-9, ls="None"))
        # outline is drawn here, without fill to prevent the glitch
        self.segments.append(SegmentCircle([0.3, 0], 0.3, fill=False))
        self.segments.append(SegmentCircle([1 - 0.3, 0], 0.3, fill=False))
        self.elmparams['theta'] = 90
        self.anchors['common'] = (0.5, math.sqrt(0.3**2 - 0.2**2))


class VoltageMirror(Element2Term):
    ''' Voltage mirror with optional common terminal

        This element does not support filling

        Anchors:
            * scommon
    '''
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.segments.append(Segment([[0, 0], [0, 0], gap, [1, 0], [1, 0]], userparams=self._userparams))
        self.segments.append(SegmentArc(center=[0.7, 0], width=0.6, height=0.3, theta1=0, theta2=360))
        self.segments.append(SegmentArc(center=[0.3, 0], width=0.6, height=0.3, theta1=0, theta2=360))
        self.elmparams['theta'] = 90
        self.anchors['common'] = (0.5, math.sqrt(1 - 0.2**2/0.3**2)*0.15)


# default to IEC style
Resistor = ResistorIEC
ResistorVar = ResistorVarIEC
Photoresistor = PhotoresistorIEC
Potentiometer = PotentiometerIEC
Fuse = FuseIEC
Inductor = InductorIEC

# Old names
RBox = ResistorIEC
RBoxVar = ResistorVarIEC
PotBox = PotentiometerIEC
PhotoresistorBox = PhotoresistorIEC
